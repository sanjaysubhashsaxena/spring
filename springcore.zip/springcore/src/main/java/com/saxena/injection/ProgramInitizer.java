package com.saxena.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProgramInitizer {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("springinjection.xml");
		Tyre ty = (Tyre) context.getBean("tyre");
		System.out.println(ty);
	}
}
