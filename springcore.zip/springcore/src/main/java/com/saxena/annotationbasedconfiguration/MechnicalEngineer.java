package com.saxena.annotationbasedconfiguration;

import org.springframework.stereotype.Component;

@Component
public class MechnicalEngineer implements Employee {
	public void salary() {
		System.out.println("Mechnical Engineer Salary");
	}
}
