package com.saxena.annotationbasedconfiguration;

public interface Employee {

	void salary();

}
