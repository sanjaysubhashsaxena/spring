package com.saxena.annotationbasedconfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringCore {
	public static void main(String[] args) {
		System.out.println("-----Annotation based configuration------");
		ApplicationContext context = new ClassPathXmlApplicationContext("springannotationbased.xml");
		Employee emp = (Employee)context.getBean("mechnicalengineer");
		emp.salary();
	}
}
