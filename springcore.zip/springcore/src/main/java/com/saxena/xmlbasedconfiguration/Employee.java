package com.saxena.xmlbasedconfiguration;

public interface Employee {

	void salary();

}
