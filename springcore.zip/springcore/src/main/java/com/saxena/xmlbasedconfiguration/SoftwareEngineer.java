package com.saxena.xmlbasedconfiguration;

public class SoftwareEngineer implements Employee {
	public void salary() {
		System.out.println("Software Engineer Salary");
	}
}
