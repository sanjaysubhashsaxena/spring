package com.saxena.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProgramInitizer {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("springautowire.xml");
//		Tyre ty = (Tyre) context.getBean("tyre");
//		System.out.println(ty);
		Car ty = (Car) context.getBean("car");
		ty.drive();
	}
}
